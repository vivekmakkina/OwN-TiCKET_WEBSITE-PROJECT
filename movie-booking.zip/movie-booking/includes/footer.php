<footer>
    <p>&copy; 2025 Movie Ticket Booking System</p>
</footer>
</body>
</html>
